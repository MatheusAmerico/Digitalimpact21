package com.digitalimpact21.Globalimpact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalimpactApplicationTests {

	@Test
	void contextLoads() {
	}

}
