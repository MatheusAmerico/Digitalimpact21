package ProdutoRepository;

import Diretório.Adicionais;
import org.springframework.data.repository.CrudRepository;

public interface AdicionaisRepository extends CrudRepository<Adicionais, String> {
}
