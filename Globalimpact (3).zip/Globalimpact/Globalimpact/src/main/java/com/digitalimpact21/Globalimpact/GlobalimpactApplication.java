package com.digitalimpact21.Globalimpact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalimpactApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalimpactApplication.class, args);
	}

}
